x = 10
y = 5

soma = x + y

print ("A soma dos números é igual a", soma)
