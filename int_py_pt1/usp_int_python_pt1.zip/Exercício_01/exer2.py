def main():

	n = int(input("Insira o número a ser verificado: "))

	if n % 3 == 0:
		print ("Fizz")
	else:
		print (n)

main()
