def main():

	n = int(input("Insira o número a ser verificado: "))

	if n % 2 == 0:
		print ("par")
	else:
		print ("ímpar")

main()
