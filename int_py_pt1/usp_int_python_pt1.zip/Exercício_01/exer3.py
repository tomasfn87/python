def main():

	n = int(input("Insira o número a ser verificado: "))

	if n % 5 == 0:
		print ("Buzz")
	else:
		print (n)

main()
