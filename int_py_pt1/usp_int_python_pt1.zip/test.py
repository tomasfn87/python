def main():
	nome = input("Insira o seu nome: ")
	print("O seu nome é ", nome)
	print("Tenha um bom dia.")

main()