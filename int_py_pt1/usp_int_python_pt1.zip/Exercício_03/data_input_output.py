def main():
	nc = input("Digite o nome do cliente: ")
	dv = input("Digite o dia de vencimento: ")
	mv = input("Digite o mês de vencimento: ")
	vf = input("Digite o valor da fatura: ")

	print("Olá,", nc)
	print("A sua fatura com vencimento em", dv,"de", mv,"no valor de R$", vf,"está fechada.")
main()