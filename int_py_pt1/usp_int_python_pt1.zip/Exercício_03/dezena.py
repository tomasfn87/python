def main():
	iN = int(input("Digite um número inteiro: "))
	oD = (iN // 10) % 10
	
	print("O dígito das dezenas é", oD)
main()