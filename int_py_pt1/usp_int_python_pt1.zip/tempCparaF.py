def main():
	tempC = float(input("Insira a temperatura em Celsius: "))
	tempF = float((tempC * 9 / 5) + 32)
	print("A temperatura em fahrenheit é", tempF,)
	
main()