def main(): 
	tempoDeJogo = int(input("Quanto tempo temos já jogados? "))
	
	if tempoDeJogo < 90:
		print("Ainda tem jogo pela frente")
		print("Que bom, eu adoro futebol")
	else:
		print("Putz, tá acabando o jogo")
		print("Apita logo, juiz!")
main()