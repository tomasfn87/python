def main():
	lado = int(input("Insira o valor do lado do quadrado: "))
	per= lado*4
	area= lado**2
	print("perímetro:", per,"- área:", area)
main()