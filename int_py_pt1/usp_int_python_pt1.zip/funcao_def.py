def soma(x, y, z):
    return x + y + z

def multi(x, y, z):
    return x * y *z 

def banda_preferida():
    return "Parliament Funkadelic"

def silencio():
    x = 10 + 20
    print("O valor calculado  é", x)
    return x
    
print(soma(5, 20, 25))
print(soma(-25, 75, 50))
print(multi(5, 20, 25))
print(multi(25, 75, 50))
print(banda_preferida())
#silencio()
print(silencio())