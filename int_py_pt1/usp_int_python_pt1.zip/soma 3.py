def main():
	x = int(input("Insira o primeiro número:"))
	y = int(input("Insira o segundo número:"))
	
	soma = x + y
	
	print ("A soma de", x, "+", y, "é igual a", soma)

main()