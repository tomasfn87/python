lista_numero_1 = [1]
lista_numero_2 = [1, 2]
lista_numero_3 = [1, 2 ,3]
lista_numero_4 = [1, 2 ,3, 4]
lista_numero_5 = [1, 2 ,3, 4, 5]
lista_numero_6 = [1, 2 ,3, 4, 5, 6]
lista_numero_7 = [1, 2 ,3, 4, 5, 6, 7]
lista_numero_8 = [1, 2 ,3, 4, 5, 6, 7, 8]
lista_numero_9 = [1, 2 ,3, 4, 5, 6, 7, 8, 9]

print('Agora vamos imprimir todas as listas:\n\n',
                             lista_numero_1, '\n', 
                             lista_numero_2, '\n', 
                             lista_numero_3, '\n', 
                             lista_numero_4, '\n', 
                             lista_numero_5, '\n', 
                             lista_numero_6, '\n', 
                             lista_numero_7, '\n', 
                             lista_numero_8, '\n', 
                             lista_numero_9
     )       