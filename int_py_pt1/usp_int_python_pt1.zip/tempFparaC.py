def main():
	tempF = float(input("Insira a temperatura em Fahrenheit: "))
	tempC = float((tempF - 32) *5 / 9)
	print("A temperatura em celsius é", tempC)
	
main()
